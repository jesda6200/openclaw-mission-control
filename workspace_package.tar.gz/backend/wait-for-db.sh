#!/usr/bin/env bash
# wait-for-db.sh: attend que Postgres soit prêt avant de démarrer l'app.
set -e

host=${DATABASE_HOST:-db}
port=${DATABASE_PORT:-5432}
user=${DATABASE_USER:-postgres}

echo "Waiting for postgres at ${host}:${port}..."

until pg_isready -h "$host" -p "$port" -U "$user" >/dev/null 2>&1; do
  echo "Postgres is not ready - sleeping 1s"
  sleep 1
done

echo "Postgres is up - continuing"
exec "$@"
