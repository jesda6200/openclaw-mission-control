DELIVERABLE — Livraison initiale

Ce document liste ce qui a été créé/organisé pour la livraison de l'état initial du projet.

Branches/structure créées:
- main (squelette initial)
- backend/
- frontend/
- infra/
- scripts/

Fichiers ajoutés/complétés:
- README.md (root)
- backend/README.md
- frontend/README.md
- infra/README.md
- CHANGELOG.md
- DELIVERABLE.md
- TEST_CHECKLIST.md (exists)

Commandes utiles pour tests & runs:
- Lancer tout (docker):
  cd infra && docker-compose up --build

- Initialiser DB schema (via container):
  docker exec -it $(docker-compose ps -q db) psql -U postgres -f /docker-entrypoint-initdb.d/01_create_schema.sql

- Seed symbols (local or inside container):
  node scripts/seed_symbols.js

- Run backend locally:
  cd backend && npm ci && npm run start:dev

- Run frontend locally:
  cd frontend && npm ci && npm run dev

PR checklist (pour la livraison initiale):
- [ ] README racine avec instructions run-local
- [ ] READMEs spécifiques pour backend/frontend/infra
- [ ] docker-compose fonctionne et démarre db/redis/backend/frontend
- [ ] init SQL présent et testé
- [ ] scripts de seed/demo présents et documentés
- [ ] CHANGELOG initial créé
- [ ] Tests basiques (health endpoint) documentés

Notes pour relecture:
- Vérifier variables d'environnement sensibles avant push
- Ajouter scripts de migration formels (Flyway/TypeORM) si nécessaire

Archive prête: push du repo ou zipper workspace root pour livraison.
