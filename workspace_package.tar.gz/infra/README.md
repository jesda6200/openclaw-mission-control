Infra (docker-compose) — instructions

Services fournis:
- TimescaleDB (Postgres)
- Redis
- backend (build from ../backend)
- frontend (build from ../frontend)

Run locally with Docker:
1) Copy .env example
   cp env.example .env

2) Start compose
   docker-compose up --build

3) Initialize DB schema (exec into container):
   docker exec -it $(docker ps -qf "name=timescaledb"); # or use docker-compose ps -q db
   docker exec -it $(docker-compose ps -q db) psql -U postgres -f /docker-entrypoint-initdb.d/01_create_schema.sql

Environment variables of interest:
- DATABASE_URL used by backend: postgres://postgres:postgres@db:5432/postgres
- REDIS_URL: redis://redis:6379

Init scripts directory: /infra/init — SQL files are applied manually or by mounting into the DB container's /docker-entrypoint-initdb.d.
